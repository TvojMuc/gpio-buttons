#!/bin/bash

echo "Removing gpio-buttons"
rm -rf /data/configuration/miscellanea/gpio-buttons
echo "Done"

echo "pluginuninstallend"